
<?php echo $__env->make('admin.auth.login_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Landing-Page-Banner-Start-->
<section class="landing-herobanner">
<div class="herobanner" style="background-image: url('<?php echo e(asset('assets/admin/images/bg-cover.png')); ?>');">
    <div class="container-xl ">
      <div class="d-flex flex-column gap-5">
      <div class="col-md-12">
        <div class="d-block text-center banner-contentbox login-contentbox">
          <div class="logo-clr">
            <img src="<?php echo e(asset('assets/admin/images/qadampayk-dash.png')); ?>" width="200" alt="logo">
          </div>
          <div class="login-box mx-auto">  
                               
            <!-- Login Form -->
            <form id="login-form" action="<?php echo e(route('login.submit')); ?>" class="login-formbox" method="POST">
              <?php echo csrf_field(); ?>
              <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert" id="success-message">
                    <?php echo e(session('success')); ?>

                  </div>
              <?php endif; ?> 
              <div class="user-iconbox d-flex justify-content-center">
                <img src="<?php echo e(asset('assets/admin/images/user-icon.png')); ?>" alt="user-icon">
              </div>
              <div class="d-block mb-2">
                <div class="icon-box <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <input type="text"  name="email" id="username" placeholder="Email" value="<?php echo e(old('email', Cookie::get('email'))); ?>"> 
                </div>
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-start error-msg-field error-message" ><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
              </div>
              <div class="d-block mb-2">
                <div class="icon-box password-icon <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                  <input type="password" name="password" id="pass" placeholder="Password" value="<?php echo e(Cookie::get('password')); ?>" >
                  <span toggle="#pass" class="fa fa-fw fa-eye-slash toggle-password text-black" style="cursor: pointer;"></span>

                </div>
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="text-start error-msg-field error-message" ><?php echo e($message); ?></div>
                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
              
              <div class="d-flex justify-content-between align-items-center mb-4">
                <div class="checkbox-group">
                  <input class="rounded-checkbox" name="remember" value="1" id="check1" type="checkbox" <?php echo e(Cookie::get('email') ? 'checked' : ''); ?>>
                  <label for="check1">Remember me</label>
                </div>
                <!-- <a class="forgot-pass" href="<?php echo e(route('forgot-password')); ?>" id="forgot-password-link">Forgot Password?</a> -->
              </div>
              <button type="submit" id="submit" value="LOGIN" class="login-btn-box">Login</button>
            </form>
          </div>
        </div>
      </div>
   
     </div>
    </div>
  </div>
  <?php echo $__env->make('admin.auth.login_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    
  
<?php /**PATH /var/www/myapp/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>