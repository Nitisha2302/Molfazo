<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>QADAMPAYK</title>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <link rel="icon" href="<?php echo e(asset('favicon-qadampayk.png')); ?>" type="image/x-icon">
  <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" integrity="sha512-1ycn6IcaQQ40/MKBW2W4Rhis/DbILU74C1vSrLJxCq57o941Ym01SwNsOMqvEBFlcgUa6xLiPY/NS5R+E6ztJQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="<?php echo e(asset('assets/admin/bootstrap/bootstrap.min.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/style.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('assets/style-new.css')); ?>">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

  
  <?php echo $__env->make('admin.css.custom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>

<div class="overlay-box"></div>
<!-- header -->
<?php echo $__env->make('admin.layouts.nav-top', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- header -->


<!-- sidenavbar -->
<?php echo $__env->make('admin.layouts.side-nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- sidenavbar -->



<!-- main-content -->
 
<div class="main">
  <?php echo $__env->yieldContent('content'); ?>
<div>
<!-- main-content -->

<script src="<?php echo e(asset('assets/admin/js/custom-js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/custom-js/custom.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/admin-js/admin.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/ckeditor/ckeditor.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/bootstrap-js/bootstrap.bundle.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

</body>
</html><?php /**PATH /var/www/myapp/resources/views/admin/layouts/app.blade.php ENDPATH**/ ?>