<?php $__env->startSection('content'); ?>
<div class="main-box-content main-space-box ">
    <section class="project-doorbox">
       <div class="ai-training-data-wrapper d-flex align-items-baseline justify-content-between">
         <div class="heading-content-box">
            <h2>Car Listing</h2>
            <div id="successMessage" class="alert alert-success d-none"></div>
            <?php if(session('success')): ?>
                <div class="alert alert-success" role="alert" id="success-message">
                    <?php echo e(session('success')); ?>

                </div>
            <?php endif; ?>
            <!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry...</p> -->
        </div>

        <div id="notificationMessage" class="alert d-none" role="alert"></div>
           
        <a href="<?php echo e(route('dashboard.admin.car')); ?>" class="btn btn-green">Add Car</a></br></br>

       </div> 
       <div id="notificationMessage" class="alert d-none" role="alert"></div>
        <div class="project-ongoing-box">
           <table class="table table-striped table-bordered table-notification-list">
                <thead>
                    <tr>
                        <th>Car Model</th>
                        <th>Brand</th>
                         <th>Seats</th>
                         <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td> <?php echo e($car->model_name ?? 'N/A'); ?></td>
                            <td><?php echo e($car->brand ?? 'N/A'); ?></td>
                            <td><?php echo e($car->seats ?? 'N/A'); ?></td> 
                            <td>                                            
                                <div class="d-flex align-items-center gap-2">
                                    <a href="<?php echo e(route('dashboard.admin.edit-car', ['id' => $car->id])); ?>" class="action-btn">
                                    <i class="fas fa-edit"></i> <span class="edit-span"></span>
                                    </a>
                                    <button  class="dropdown-item delete-btn-design delete-car-btn d-flex justify-content-center" data-car-id="<?php echo e($car->id); ?>" type="button" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
                                        <i class="fa fa-regular fa-trash"></i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                      <td colspan="12" class="text-center">No data found.</td>
                    </tr>
                  <?php endif; ?>                 
                </tbody>
            </table>
        </div>
        <?php
            $carList = isset($search_cars) && $search_cars->isNotEmpty() ? $search_cars : $cars;
        ?>
        <?php if($carList->lastPage() > 1): ?>
            <nav class="pt-3" aria-label="Page navigation">
                <ul class="pagination" id="pagination-links">
                    
                    <?php if($carList->onFirstPage()): ?>
                        <li class="page-item disabled"><span class="page-link text-dark">Previous</span></li>
                    <?php else: ?>
                        <li class="page-item"><a class="page-link text-dark" href="<?php echo e($carList->previousPageUrl()); ?>">Previous</a></li>
                    <?php endif; ?>

                    
                    <?php for($i = 1; $i <= $carList->lastPage(); $i++): ?>
                        <li class="page-item <?php echo e($carList->currentPage() == $i ? 'active' : ''); ?>">
                            <a class="page-link" href="<?php echo e($carList->url($i)); ?>"><?php echo e($i); ?></a>
                        </li>
                    <?php endfor; ?>

                    
                    <?php if($carList->hasMorePages()): ?>
                        <li class="page-item"><a class="page-link text-dark" href="<?php echo e($carList->nextPageUrl()); ?>">Next</a></li>
                    <?php else: ?>
                        <li class="page-item disabled"><span class="page-link text-dark">Next</span></li>
                    <?php endif; ?>
                </ul>
            </nav>
        <?php endif; ?>


    </section>  
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <!-- delete-confirmation-popup -->
         <section class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header border-0">
                        <h2 class="delete-confirmation-popup-title delete-user-confirmation-popup-title" id="staticBackdropLabel">Are you sure?</h2>
                        <button type="button" class="btn-close cancel-popup-btnbox" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body delete-confirmation-popup-body ">
                            <p class="delete-confirmation-popup-text delete-user-confirmation-popup-text">Do you really want to delete this car?</p>
                    </div>
                    <div class="modal-footer border-0 delete-confirmation-popup-footer delete-user-confirmation-popup-footer">
                        <button class="delete-confirmation-popup-btn btn" data-bs-dismiss="modal" aria-label="Close">Cancel</button>
                        <button class="delete-confirmation-popup-btn btn delete-confirmation-popup-delete-btn delete-car-confirmation-popup-delete-btn" data-car-id="">Delete</button>
                    </div>
                </div>
            </div>
        </section>
    <!-- delete-confirmation-popup-->
<?php $__env->stopSection(); ?>

<script>
    const csrfToken = "<?php echo e(csrf_token()); ?>";
     const deleteCarUrl = "<?php echo e(url('dashboard/admin/delete-car')); ?>"; 
</script>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/myapp/resources/views/admin/car/carListing.blade.php ENDPATH**/ ?>