<div class="footer-navbar">
    <a href="<?php echo e(route('login')); ?>">Copyright QADAMPAYK</a>
    <a href="">Privacy Policy</a>
   
  </div>
</section>
<script src="<?php echo e(asset('assets/admin/js/custom-js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/admin/js/custom-js/custom.js')); ?>"></script>

</body>
</html><?php /**PATH /var/www/myapp/resources/views/admin/auth/login_footer.blade.php ENDPATH**/ ?>