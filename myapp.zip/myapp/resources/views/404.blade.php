<div style="text-align: center; margin-top: 80px; font-family: Arial, sans-serif; color: #2c3e50;">
    <h1 style="font-size: 96px; font-weight: bold; margin-bottom: 10px; color: #008955;">404</h1>
    <h3 style="font-size: 28px; margin-bottom: 10px;">Oops! Page Not Found</h3>
    <p style="font-size: 18px; color: #7f8c8d; margin-bottom: 30px;">
        The page you are looking for does not exist or has been moved.
    </p>
    <!-- <a href="{{ url('/') }}" style="display: inline-block; padding: 12px 24px; background-color: #3498db; color: white; text-decoration: none; border-radius: 6px;">
        Terug naar Home
    </a> -->
</div>
