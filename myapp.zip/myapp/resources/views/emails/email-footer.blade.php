<div class="footer">© 2025 Hewie. All rights reserved.</div>
</div>
</body>

</html>