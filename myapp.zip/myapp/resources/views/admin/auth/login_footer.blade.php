<div class="footer-navbar">
    <a href="{{route('login')}}">Copyright QADAMPAYK</a>
    <a href="">Privacy Policy</a>
   
  </div>
</section>
<script src="{{ asset('assets/admin/js/custom-js/jquery.min.js') }}"></script>
<script src="{{ asset('assets/admin/js/custom-js/custom.js') }}"></script>

</body>
</html>