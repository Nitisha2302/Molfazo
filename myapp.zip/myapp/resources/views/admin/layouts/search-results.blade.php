@extends('layouts.app')

@section('content')
ndmcdnm
@endsection
